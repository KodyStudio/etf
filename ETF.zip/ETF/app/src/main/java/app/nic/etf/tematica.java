package app.nic.etf;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.VideoView;

import com.example.etf.R;
import com.google.android.gms.ads.AdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class tematica extends AppCompatActivity {

    VideoView videoView;
    MediaPlayer mp;
    private InterstitialAd mInterstitialAd;
    private static final long DURACION_SPLASH = 3000;
    private final int duracion_splash;

    {
        duracion_splash = 3;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //full screen ↓↓↓
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        //full screen ↑↑↑↑

        setContentView(R.layout.activity_tematica);

        //ad
        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-3102701266527219/7759321669");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        // ↓↓↓ MUSIC ↓↓↓
        List<Uri> listmusica = new ArrayList<>();
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess1.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess2.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess3.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess6.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess7.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess8.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess9.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/chess/chess10.mp3"));
        //==========================================================================================
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar1.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar2.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar3.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar4.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar5.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar6.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar7.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar8.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar9.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/eznar/eznar10.mp3"));
        //==========================================================================================
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn1.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn3.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn4.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn5.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn6.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn7.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn8.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn9.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn10.mp3"));
        //==========================================================================================
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha1.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha2.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha3.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha4.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha5.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha6.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha7.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha8.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha9.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/panchaone/pacha10.mp3"));
        //==========================================================================================
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn1.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn3.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn4.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn5.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn6.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn7.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn8.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn9.mp3"));
        listmusica.add(Uri.parse("https://instrumentaless.s3.us-east-2.amazonaws.com/zorn/zorn10.mp3"));
//
        mp = MediaPlayer.create(this, (listmusica.get(new Random().nextInt(listmusica.size()))));
        // ↑↑↑↑ MUSIC ↑↑↑↑

        // ↓↓↓ VIDEO ↓↓↓
        videoView = (VideoView) findViewById(R.id.vv);
        List<String> listUri = new ArrayList<>();
        videoView.setVideoURI
        (Uri.parse("https://tematicas.s3.us-east-2.amazonaws.com/t1.mp4"));
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t1.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t2.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t3.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t4.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t5.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t6.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t7.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t8.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t9.mp4");
        listUri.add("https://tematicas.s3.us-east-2.amazonaws.com/t10.mp4");
        videoView.setVideoPath(listUri.get(new Random().nextInt(listUri.size())));
        videoView.setVisibility(View.VISIBLE);
        videoView.requestFocus();
        // ↑↑↑↑ VIDEO ↑↑↑↑

        // ↓↓↓ play ↓↓↓
        new Handler().postDelayed(new Runnable() {
            public void run() {
                videoView.start();
                mp.start();
            }
            ;
        }, DURACION_SPLASH);
        // ↑↑↑↑ play ↑↑↑↑

        // ↓↓↓ ad end video change activity ↓↓↓
        videoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Intent i = new Intent(tematica.this, MainActivity.class);
                    startActivity(i);
                    // Code to be executed when the interstitial ad is closed.
                }
            }
        });
        mInterstitialAd.setAdListener(new AdListener() {
            public void onAdClosed () {
                Intent i = new Intent(tematica.this, MainActivity.class);
                startActivity(i);
            }
        });
    }
    public void onCompletion(MediaPlayer mediaPlayer) {
        finish();
    }
        public void onPrepared(MediaPlayer mp) {
            videoView.start();
        }
    // ↓↓↓ stop music if i change activity ↓↓↓
    public void onPause()
    {
        super.onPause();
        mp.pause();
    }
    // ↑↑↑↑ stop music if i change activity ↑↑↑↑

    // ↓↓↓ button for change activity ↓↓↓
    public void atras (View view){
        Intent atras = new Intent(this, MainActivity.class);
        startActivity(atras);
    }
}
// ↑↑↑↑ button for change activity ↑↑↑↑